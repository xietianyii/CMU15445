select categoryname from category order by categoryname
